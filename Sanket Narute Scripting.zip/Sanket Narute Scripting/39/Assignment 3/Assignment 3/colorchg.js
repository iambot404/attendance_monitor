        document.addEventListener('click', function() {
            const colors = ['skyblue'];
            document.body.style.backgroundColor = colors;
        });