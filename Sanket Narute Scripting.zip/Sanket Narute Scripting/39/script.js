document.addEventListener("click", function () {
    let colors = ["red", "green", "blue", "yellow", "pink", "orange"];
    let randomColor = colors[Math.floor(Math.random() * colors.length)];
    document.body.style.backgroundColor = randomColor;
  });
  